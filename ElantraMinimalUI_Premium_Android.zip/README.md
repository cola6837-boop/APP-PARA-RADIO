# Elantra Minimal UI — Modo Radio

Launcher Android experimental para radio RK3326 (1280×720). Incluye reloj, dibujo frontal rojo cereza, controles multimedia básicos, aplicaciones instaladas y accesos a navegación, radio, teléfono, Bluetooth, música y PhoneLink.

**Limitaciones:** los nombres internos de las apps de radio/PhoneLink varían por fabricante. La carátula, título real, barra de progreso y velocidad real NO están implementados. Los controles multimedia pueden depender de la app activa. La cámara de reversa y mandos del volante no se modifican, pero deben verificarse antes de establecer como launcher predeterminado.

Primero probar en teléfono. No borrar el launcher original ni instalar firmware.


Actualización: animación de entrada breve, respuesta táctil animada, indicador de conectividad de Internet, permisos de red. Internet se utiliza a través de apps instaladas; no existe aún cliente de streaming integrado. No se ha validado en hardware RK3326.
