package com.elantra.minimalui;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.animation.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
  final int BG=Color.rgb(8,10,14), PANEL=Color.rgb(19,23,30), MUTED=Color.rgb(169,177,190);
  LinearLayout root; TextView clock, date, track; Handler handler=new Handler();
  int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
  GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));g.setStroke(dp(1),Color.rgb(40,45,55));return g;}
  TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
  LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);return l;}
  LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,-1,1);}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);draw();}
  void draw(){
    root=col();root.setPadding(dp(18),dp(10),dp(18),dp(12));root.setBackgroundColor(BG);setContentView(root);
    LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);
    TextView brand=text("◈  HYUNDAI   ·   ELANTRA",15,Color.WHITE);top.addView(brand,new LinearLayout.LayoutParams(0,dp(38),1));
    TextView status=text("MODO RADIO  •  ANDROID",12,MUTED);status.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);top.addView(status);
    ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE); NetworkInfo net=cm==null?null:cm.getActiveNetworkInfo(); status.setText((net!=null && net.isConnected()?"● ONLINE":"○ SIN CONEXIÓN")+"  ·  MODO RADIO");root.addView(top);
    View line=new View(this);line.setBackgroundColor(Color.rgb(45,49,59));root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
    LinearLayout center=row();LinearLayout.LayoutParams centerP=new LinearLayout.LayoutParams(-1,0,1);centerP.topMargin=dp(12);root.addView(center,centerP);
    LinearLayout left=col();left.setPadding(dp(18),dp(12),dp(12),dp(12));left.setBackground(shape(PANEL,22));center.addView(left,new LinearLayout.LayoutParams(0,-1,1.05f));
    date=text("",15,MUTED);left.addView(date);
    clock=text("",48,Color.WHITE);clock.setTypeface(null,1);left.addView(clock,new LinearLayout.LayoutParams(-1,dp(70)));
    TextView caption=text("ELANTRA  ·  CHERRY RED",12,MUTED);left.addView(caption);
    CarView car=new CarView(this);left.addView(car,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout right=col();LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1.2f);rp.leftMargin=dp(12);center.addView(right,rp);
    LinearLayout music=col();music.setPadding(dp(18),dp(12),dp(18),dp(12));music.setBackground(shape(PANEL,22));right.addView(music,new LinearLayout.LayoutParams(-1,0,1));
    TextView now=text("♫   REPRODUCCIÓN",13,MUTED);music.addView(now);
    track=text("Control multimedia",23,Color.WHITE);track.setTypeface(null,1);music.addView(track,new LinearLayout.LayoutParams(-1,0,1));
    TextView info=text("Los títulos y portadas requieren integración multimedia compatible",12,MUTED);info.setMaxLines(2);music.addView(info);
    LinearLayout ctr=row();ctr.setGravity(Gravity.CENTER);music.addView(ctr,new LinearLayout.LayoutParams(-1,dp(54)));
    control(ctr,"⏮",KeyEvent.KEYCODE_MEDIA_PREVIOUS);control(ctr,"⏯",KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);control(ctr,"⏭",KeyEvent.KEYCODE_MEDIA_NEXT);
    LinearLayout quick=row();LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-1,dp(64));qp.topMargin=dp(10);right.addView(quick,qp);
    quick(quick,"◉", "Bluetooth",new String[]{"com.android.bluetooth","com.android.settings"},"android.settings.BLUETOOTH_SETTINGS");
    quick(quick,"☎", "Teléfono",new String[]{"com.android.dialer","com.google.android.dialer"},"android.intent.action.DIAL");
    quick(quick,"↗", "PhoneLink",new String[]{"com.zjinnova.zlink","com.suding.speedplay","com.zlink","com.txznet.car"},null);
    LinearLayout dock=row();LinearLayout.LayoutParams dockP=new LinearLayout.LayoutParams(-1,dp(88));dockP.topMargin=dp(12);root.addView(dock,dockP);
    tile(dock,"◈","Navegación",Color.rgb(61,125,237),new String[]{"com.google.android.apps.maps","com.waze"},"android.intent.action.VIEW");
    tile(dock,"▣","Radio",Color.rgb(236,65,89),new String[]{"com.ts.MainUI","com.syu.radio","com.microntek.radio"},null);
    tile(dock,"☎","Llamadas",Color.rgb(36,190,100),new String[]{"com.android.dialer","com.google.android.dialer"},"android.intent.action.DIAL");
    tile(dock,"▦","Aplicaciones",Color.rgb(104,112,133),null,"APPS");
    tile(dock,"♫","Música",Color.rgb(235,69,102),new String[]{"com.spotify.music","com.google.android.apps.youtube.music","com.android.music"},"android.intent.action.MUSIC_PLAYER");
    tile(dock,"⚙","Ajustes",Color.rgb(102,109,123),new String[]{"com.android.settings"},"android.settings.SETTINGS");
    tick();
    root.setAlpha(0f);root.animate().alpha(1f).setDuration(280).start();
  }
  void tick(){SimpleDateFormat c=new SimpleDateFormat("h:mm",new Locale("es","MX"));SimpleDateFormat d=new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","MX"));Date n=new Date();clock.setText(c.format(n));date.setText(d.format(n));handler.postDelayed(()->tick(),30000);}
  void control(LinearLayout r,String label,int key){TextView b=text(label,27,Color.WHITE);b.setGravity(Gravity.CENTER);r.addView(b,new LinearLayout.LayoutParams(0,-1,1));b.setOnClickListener(v->{AudioManager a=(AudioManager)getSystemService(AUDIO_SERVICE);a.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,key));a.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,key));});}
  void quick(LinearLayout parent,String symbol,String label,String[] pkgs,String action){LinearLayout box=col();box.setGravity(Gravity.CENTER);box.setBackground(shape(PANEL,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.rightMargin=dp(7);parent.addView(box,p);TextView t=text(symbol,25,Color.rgb(102,162,255));t.setGravity(Gravity.CENTER);box.addView(t);TextView name=text(label,12,Color.WHITE);name.setGravity(Gravity.CENTER);box.addView(name);box.setOnClickListener(v->{pressAnimation(box);launch(pkgs,action);});}
  void tile(LinearLayout parent,String symbol,String label,int color,String[] pkgs,String action){LinearLayout box=col();box.setGravity(Gravity.CENTER);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);parent.addView(box,p);TextView icon=text(symbol,28,Color.WHITE);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(color,16));box.addView(icon,new LinearLayout.LayoutParams(dp(52),dp(52)));TextView name=text(label,12,Color.WHITE);name.setGravity(Gravity.CENTER);box.addView(name);box.setOnClickListener(v->{pressAnimation(box);if("APPS".equals(action))apps();else launch(pkgs,action);});}
  void pressAnimation(View v){v.animate().scaleX(.94f).scaleY(.94f).setDuration(90).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(150).start()).start();}
  void launch(String[] pkgs,String action){PackageManager pm=getPackageManager();if(pkgs!=null)for(String pkg:pkgs){Intent i=pm.getLaunchIntentForPackage(pkg);if(i!=null){try{startActivity(i);return;}catch(Exception ignored){}}}if(action!=null){try{Intent i=new Intent(action);if(action.equals("android.intent.action.VIEW"))i.setData(android.net.Uri.parse("geo:0,0?q="));startActivity(i);return;}catch(Exception ignored){}}Toast.makeText(this,"Aplicación no encontrada: configurar acceso en una próxima versión",Toast.LENGTH_LONG).show();}
  void apps(){final ArrayList<ResolveInfo> all=new ArrayList<>();Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);all.addAll(getPackageManager().queryIntentActivities(intent,0));Collections.sort(all,new ResolveInfo.DisplayNameComparator(getPackageManager()));String[] names=new String[all.size()];for(int i=0;i<all.size();i++)names[i]=all.get(i).loadLabel(getPackageManager()).toString();new AlertDialog.Builder(this).setTitle("Aplicaciones instaladas").setItems(names,(d,which)->{ResolveInfo ri=all.get(which);Intent launch=getPackageManager().getLaunchIntentForPackage(ri.activityInfo.packageName);if(launch!=null)startActivity(launch);}).setNegativeButton("Cerrar",null).show();}
  @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
  class CarView extends View {Paint p=new Paint(3);CarView(Context c){super(c);}void fill(Canvas c,int color,Paint.Style style,float width){p.setColor(color);p.setStyle(style);p.setStrokeWidth(width);}protected void onDraw(Canvas original){super.onDraw(original);Canvas c=original;int save=c.save();float w=getWidth(),h=getHeight();c.translate(w*.5f,h*.54f);float scale=Math.min(w/440f,h/250f);c.scale(scale,scale);fill(c,0x44000000,Paint.Style.FILL,0);c.drawOval(-180,77,180,107,p);fill(c,0xFF9C1025,Paint.Style.FILL,0);RectF body=new RectF(-180,-32,180,83);c.drawRoundRect(body,32,32,p);Path roof=new Path();roof.moveTo(-122,-30);roof.lineTo(-91,-105);roof.quadTo(0,-132,91,-105);roof.lineTo(122,-30);roof.close();fill(c,0xFFBD1731,Paint.Style.FILL,0);c.drawPath(roof,p);Path glass=new Path();glass.moveTo(-91,-39);glass.lineTo(-72,-95);glass.quadTo(0,-113,72,-95);glass.lineTo(91,-39);glass.close();fill(c,0xFF19212B,Paint.Style.FILL,0);c.drawPath(glass,p);fill(c,0xFF4B0712,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-153,12,153,67),13,13,p);fill(c,0xFF10151B,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-117,23,117,62),13,13,p);fill(c,0xFFFAFAF9,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-170,-11,-108,15),10,10,p);c.drawRoundRect(new RectF(108,-11,170,15),10,10,p);fill(c,0xFFB5C8DB,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-158,-5,-112,8),7,7,p);c.drawRoundRect(new RectF(112,-5,158,8),7,7,p);fill(c,0xFFDDDFE2,Paint.Style.STROKE,5);c.drawOval(-22,17,22,38,p);fill(c,0xFF7B0C1F,Paint.Style.FILL,0);c.drawRect(-175,57,-149,88,p);c.drawRect(149,57,175,88,p);c.restoreToCount(save);}}
}
